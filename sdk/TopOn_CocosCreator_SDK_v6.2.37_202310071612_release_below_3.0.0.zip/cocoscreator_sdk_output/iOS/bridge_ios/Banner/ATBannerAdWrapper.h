//
//  ATBannerAdWrapper.h
//  AnyThinkSDKDemo
//
//  Created by Martin Lau on 2020/4/16.
//  Copyright © 2020 AnyThink. All rights reserved.
//

#import "ATAdWrapper.h"
@interface ATBannerAdWrapper : ATAdWrapper

@end
