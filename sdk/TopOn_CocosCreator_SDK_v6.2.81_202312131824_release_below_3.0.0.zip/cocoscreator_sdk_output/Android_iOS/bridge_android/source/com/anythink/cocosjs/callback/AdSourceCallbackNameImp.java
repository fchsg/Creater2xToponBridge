package com.anythink.cocosjs.callback;

public interface AdSourceCallbackNameImp {
    public String getBiddingAttemptMethodName();
    public String getBiddingFilledMethodName();
    public String getBiddingFailMethodName();
    public String getAttempMethodName();
    public String getLoadFilledMethodName();
    public String getLoadFailMethodName();
}
